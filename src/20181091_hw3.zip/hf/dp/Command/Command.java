package hf.dp.Command;

public interface Command {
  abstract public void execute();
}
