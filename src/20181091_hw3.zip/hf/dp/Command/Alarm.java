package hf.dp.Command;

public class Alarm {
  public void start() {
    System.out.println("Alarming...");
  }
}
