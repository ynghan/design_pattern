package hf.dp.Command;

public class Lamp {
  public void turnOn() {
    System.out.println("Lamp On");
  }
}
