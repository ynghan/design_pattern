package hf.dp.Strategy;

public interface Flyable {

    public void fly();
}
