package hf.dp.Strategy.quack;

public interface QuackBehavior {
    public void quack();
}
