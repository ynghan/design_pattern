package hf.dp.Strategy;

public interface Quackable {
    public void quack();
}
