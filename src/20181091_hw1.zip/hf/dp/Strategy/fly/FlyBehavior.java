package hf.dp.Strategy.fly;

public interface FlyBehavior {
    public void fly();
}
