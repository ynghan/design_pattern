package hf.dp.Strategy;

import hf.dp.Strategy.duck.Duck;

public class DecoyDuck extends Duck {
    public void quack() {

    }

    public void display() {
        System.out.println("showing decoy duck");
    }

    public void fly() {

    }
}
