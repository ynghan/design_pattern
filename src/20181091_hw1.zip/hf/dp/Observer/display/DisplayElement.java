package hf.dp.Observer.display;

public interface DisplayElement {
    public void display();
}
